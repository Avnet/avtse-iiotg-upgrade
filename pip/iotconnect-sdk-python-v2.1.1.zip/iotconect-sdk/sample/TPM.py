"""
after installing the IoTConnectSDK please run this sample.

To run this sample you need env,uniqueId,cpId
	env:- It is environment that you have to pass at the inialization of SDK
	uniqueId:- which you get from IOthub/Iotconnect
	cpId:- which you get from IOthub/Iotconnect
	scopeId:-you will get from our team

				
"""
# Compatible with python 2.* version
import sys
import json
import time
import threading
import random
from iotconnect import IoTConnectSDK
from datetime import datetime

#Get your "ENV" and "CPID" from the portal key vaults module or visit https://help.iotconnect.io SDK section.

env = "<<you environment>>"
uniqueId = "<<your uniqueId>>"
cpId = "<<your cpId>>"
scopeId = "<<your scopeId>>"

interval = 10 # second.. delay


tProcess = None
dataArray = []
d2cMsg = None

"""
	callbackMessage(msg)
						you will get your message and firmware update and other commands from iotconnect(cloud).
"""

def callbackMessage(msg):
    global d2cMsg
    print("\n--- Command Message Received ---")
    cmdType = None
    if msg != None and len(msg.items()) != 0:
        cmdType = msg["cmdType"] if msg["cmdType"] != None else None
    
    # Other Command
    if cmdType == "0x01":
        data = msg["data"] if msg["data"] != None else None
        if data != None:
            d2cMsg = {
                "ackId" : data['ackId'],
                "st" : 6,
                "msg" : "",
                "childId" : ""     # if child than add childid
                }
    
    # Firmware Upgrade
    if cmdType == "0x02":
        data = msg["data"] if msg["data"] != None else None
        if data != None:
            d2cMsg = {
                "ackId" : data['ackId'],
                "st" : 7,
                "msg" : "",
                "childId" : ""     # if child than add childid
            }


"""
	callbackTwinMessage(msg)
		you will get twin property from here
"""
        
def callbackTwinMessage(msg):
    if msg:
        print("\n--- Twin Message Received ---")
        print(json.dumps(msg))

def sendBackToSDK(sdk, dataArray):
    global tProcess
    sdk.SendData(dataArray)
    time.sleep(interval)
    tProcess = None

"""
before send data make sure atributes are in your Iotconnect template.
your sensors or atributes. in this sample we use Temperature and Gyroscope as atributes. 
"""


def processData():
    try:
        # Sample Data
        return {
            "Temperature": random.randint(10,50)
        }
        #return None
    except:
        return None

def main():
    global tProcess, dataArray, d2cMsg,env
    try:
      
        with IoTConnectSDK(cpId, uniqueId, scopeId, callbackMessage, callbackTwinMessage, env) as sdk:
            try:
                #sdk.GetAttributes()
                #
                # Note : cmdType = "0x02" - Firmware Upgrade
                # sdk.SendACK(d2cMsg,current_time,11) # Send acknowledgement
                # 11 : Firmware acknowledgement
                # e.g : acknowledgement data
                # {
                #   "ackId" : data['ackId'],
                #   "st" : 7,
                #   "msg" : ""
                #   "childId" : ""
                # }
                while True:
                    dataArray = []
                    data = processData()
                    if data != None:
                        dObj = {
                            "uniqueId": uniqueId,
                            "time": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.000Z"),
                            "data": data
                        }
                        dataArray.append(dObj)
                        
                    if tProcess == None and len(dataArray) == 1:
                        tProcess = threading.Thread(target = sendBackToSDK, args = [sdk, dataArray])
                        tProcess.setName("SEND")
                        tProcess.daemon = True
                        tProcess.start()
                        tProcess.join(1)

                    # Send acknowledgement
                    if d2cMsg != None:
                        if d2cMsg["st"] == 7:
                            sdk.SendACK(d2cMsg,11) # 11 : Firmware acknowledgement
                        elif d2cMsg["st"] == 6:
                            sdk.SendACK(d2cMsg,5) # 5 : command acknowledgement
                        d2cMsg = None

            except KeyboardInterrupt:
                sys.exit(0)
    except Exception as ex:
        print(ex.message)
        sys.exit(0)

if __name__ == "__main__":
    main()
